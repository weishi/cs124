cs124
=====

Direct Machine Translation

Getting started
-------

    python Translator.py

Additional Package
-------
You need to install the following packages to run.
+ http://www.clips.ua.ac.be/pattern
+ http://nlp.stanford.edu/projects/chinese-nlp.shtml#pos
