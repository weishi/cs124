### Corpus
人们 多 通过 社会 比较，来 确定 自己的 优势，和 在 社会 中 的 地位，他 认为 幸灾乐祸 就 来源于 社会性 比较。
(from http://www.guokr.com/article/437875/)

他们 发现，随着 时间 推移，听起来 明显 是 黑人的 名字 越来越 能 可靠地 表明 孩子的 社会 经济 背景。
(from http://www.guokr.com/article/437940/)

有所取舍，不仅 是 差异化 的 标志，更 是 优秀的 标志。
(from http://read.douban.com/ebook/2800884/?dcs=book-hot&dcm=douban&dct=read-subject)

所以 她 就 决定，早晚 要 打 我 一个 耳光。
(from Collections of Xiaobo Wang)

诗，就 是 以 最少的 语言，去 表达 最多 的 文字。 
(from http://book.douban.com/review/3345946/)

在 漫画 中，习近平 穿着 灰色 夹克 和 蓝色 裤子。
(from http://news.ifeng.com/mainland/detail_2014_02/20/33983439_0.shtml)

这 是 中国 社会 更 自信 和 更 开放 的 一种 姿态。
(from http://news.ifeng.com/mainland/detail_2014_02/20/33983439_0.shtml)

每个人 都 可能 是 创业者，而 这些 专业级 的 分享，会 让 创业者 不再 孤单。
(from http://read.douban.com/ebook/2595517/?icn=index-rec)

设计 不仅 意味着 风格 和 品味，还 融入 了 文化 与 个性。
(from http://read.douban.com/ebook/2593494/?icn=profile-guess)

他 向 当地 媒体 指出，法律 没有 明文 禁止 成立 这类 组织。
(from http://www.bbc.co.uk/zhongwen/simp/china/2014/02/140220_hunan_gay_lawsuit.shtml)

放弃 美国 国籍 是 个人的 选择，但 富人 要 放弃 美国 国籍 则是 需要 付出 代价 的。
(from http://blog.sina.com.cn/s/blog_5d8d68c10102ef1r.html?tj=1)

许多 中小学、大学 都 只 强调 了 知识 的 传授，而 忽视 了 对于 学生 人格 的 培养。
(from http://blog.sina.com.cn/s/blog_7159859d0102f6f8.html?tj=1)

所以 我 认为 现行 的 音乐 定价 模式 是 有 问题 的，单首 歌曲 的 价格 太 高 了。
(from http://erdong.baijia.baidu.com/article/4613)

那么，现金 怎么 花 出去，让 它 变得 更有 价值，就 成为 最 关键 的 问题。
(from http://fusheng.baijia.baidu.com/article/4680)

当 我们 面临 许多 方法 时，这些 方法 不 是 简单的 对 或者 错，捷径 或者 弯路。
(from http://www.zhihu.com/question/22790970/answer/22665239)